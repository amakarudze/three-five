# Three-Five
A program that prints numbers from 1 to 100. For multiples of 3 it prints `Three` instead and for multiples and for
5 prints `Five`. For multiples of both 3 and 5, it prints `ThreeFive`.

## Installation
Download or clone the repo to work with the source files.

To install to your project run
```pip install ```

## Tests
To run tests, run ```python3 -m unittest test_three_five```.

## Contributing
To contribute, please read the following guidelines.
